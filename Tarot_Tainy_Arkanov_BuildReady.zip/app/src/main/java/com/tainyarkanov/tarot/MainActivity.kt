package com.tainyarkanov.tarot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Midnight = Color(0xFF101429)
private val Panel = Color(0xFF202743)
private val Gold = Color(0xFFE6C780)
private val Text = Color(0xFFF4EBDC)
private val Pale = Color(0xFFC7C7D7)

private val TarotScheme = darkColorScheme(
    primary = Gold, onPrimary = Midnight, secondary = Pale, background = Midnight,
    surface = Panel, onSurface = Text, onBackground = Text
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = TarotScheme) {
                TarotApp()
            }
        }
    }
}

@Composable
private fun TarotApp(vm: TarotViewModel = viewModel()) {
    var screen by remember { mutableStateOf("home") }
    var spread by remember { mutableStateOf(TarotData.spreads[1]) }
    var topic by remember { mutableStateOf("Общее") }
    var question by remember { mutableStateOf("") }
    var reading by remember { mutableStateOf(emptyList<DrawnCard>()) }
    var selectedCard by remember { mutableStateOf<TarotCard?>(null) }
    var selectedReading by remember { mutableStateOf<ReadingEntity?>(null) }
    val history by vm.history.collectAsState()
    val reversals by vm.reversals.collectAsState()
    fun openSpread(chosen: Spread, chosenTopic: String = "Общее") {
        spread = chosen
        topic = chosenTopic
        question = ""
        screen = "prepare"
    }
    Scaffold(
        containerColor = Midnight,
        topBar = {
            Surface(color = Midnight) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (screen != "home") {
                        Text("‹", color = Gold, style = MaterialTheme.typography.headlineMedium,
                            modifier = Modifier.clickable {
                                screen = when (screen) {
                                    "result" -> "prepare"
                                    "detail" -> "library"
                                    "saved" -> "journal"
                                    else -> "home"
                                }
                            }.padding(end = 16.dp))
                    }
                    Text("✦ Таро — Тайны Арканов", color = Gold, fontWeight = FontWeight.Bold)
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("home" to "Главная", "spreads" to "Расклады", "library" to "Карты",
                    "journal" to "Дневник", "settings" to "Настройки").forEach { (key, title) ->
                    NavigationBarItem(
                        selected = screen == key,
                        onClick = { screen = key },
                        icon = { Text(when(key) {
                            "home" -> "☾"; "spreads" -> "✧"; "library" -> "♧"
                            "journal" -> "▤"; else -> "⚙"
                        }) },
                        label = { Text(title, maxLines = 1) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)) {
            when (screen) {
                "home" -> {
                    Heading("Загляните внутрь себя", "Таро как повод для размышлений, а не обещание предсказать будущее.")
                    BigAction("☀ Карта дня", "Одна карта, выбранная на сегодняшний день") {
                        spread = TarotData.spreads[0]
                        topic = "Общее"
                        question = "Карта дня"
                        reading = vm.daily()
                        screen = "result"
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Популярные расклады", color = Gold, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(8.dp))
                    TarotData.spreads.take(4).forEach { item ->
                        BigAction(item.title, item.description) { openSpread(item) }
                    }
                    BigAction("◎ Обучение", "Познакомьтесь с картами и раскладами") { screen = "learn" }
                }
                "spreads" -> {
                    Heading("Выберите расклад", "Каждая позиция помогает взглянуть на свой вопрос с другой стороны.")
                    TarotData.spreads.forEach { item -> BigAction(item.title, item.description) { openSpread(item) } }
                    BigAction("Да или нет", "Одна карта — повод рассмотреть аргументы за и против") {
                        openSpread(TarotData.spreads[0], "Да или нет")
                    }
                }
                "prepare" -> {
                    Heading(spread.title, spread.description)
                    Text("Тема", color = Gold)
                    var menuExpanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { menuExpanded = true }) { Text(topic + " ▾") }
                        DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                            listOf("Общее", "Любовь", "Работа", "Деньги", "Будущее", "Да или нет").forEach { option ->
                                DropdownMenuItem(text = { Text(option) }, onClick = { topic = option; menuExpanded = false })
                            }
                        }
                    }
                    OutlinedTextField(value = question, onValueChange = { question = it.take(500) },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Ваш вопрос (необязательно)") },
                        minLines = 2, maxLines = 4)
                    Spacer(Modifier.height(16.dp))
                    Text("Карты выбираются случайно из полной колоды без повторений. Перевёрнутые карты: ${if (reversals) "включены" else "выключены"}.",
                        color = Pale)
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = { reading = vm.draw(spread); screen = "result" }, modifier = Modifier.fillMaxWidth()) {
                        Text("Перемешать и открыть ${spread.positions.size} карт")
                    }
                }
                "result" -> {
                    Heading(if (question == "Карта дня") "Карта дня" else spread.title,
                        if (question.isNotBlank()) question else "Ваш расклад")
                    reading.forEach { drawn ->
                        CardPanel(drawn)
                        Text(TarotData.interpretation(drawn, topic), modifier = Modifier.padding(bottom = 18.dp))
                    }
                    Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Итог расклада", color = Gold, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text(TarotData.overview(reading))
                            if (topic == "Да или нет") Text("Это не достоверный ответ «да» или «нет»: используйте карту для размышления.", color = Pale)
                        }
                    }
                    var notes by remember(reading) { mutableStateOf("") }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = notes, onValueChange = { notes = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Мои заметки") }, minLines = 3)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        vm.save(if (question == "Карта дня") "Карта дня" else spread.title, topic, question, reading, notes)
                        screen = "journal"
                    }, modifier = Modifier.fillMaxWidth(), enabled = reading.isNotEmpty()) { Text("Сохранить в дневник") }
                    OutlinedButton(onClick = { reading = if (question == "Карта дня") vm.daily() else vm.draw(spread) },
                        modifier = Modifier.fillMaxWidth()) { Text("Повторить расклад") }
                }
                "library" -> {
                    Heading("Энциклопедия 78 карт", "Выберите карту, чтобы узнать её прямое и перевёрнутое значения.")
                    var search by remember { mutableStateOf("") }
                    OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("Поиск карты") }, singleLine = true)
                    TarotData.cards.filter { it.name.contains(search, ignoreCase = true) }.forEach { card ->
                        BigAction(card.name, card.suit) {
                            selectedCard = card
                            screen = "detail"
                        }
                    }
                }
                "detail" -> {
                    selectedCard?.let { card ->
                        Heading("✦ ${card.name}", card.suit)
                        SymbolCard(card.name, Modifier.fillMaxWidth().height(220.dp))
                        SectionText("Прямое значение", card.upright)
                        SectionText("Перевёрнутое значение", card.reversed)
                        SectionText("Символика", card.symbol)
                    }
                }
                "journal" -> {
                    Heading("Дневник раскладов", "Всё хранится только на вашем устройстве.")
                    if (history.isEmpty()) Text("Здесь появятся сохранённые расклады.", color = Pale)
                    history.forEach { entry ->
                        BigAction(entry.title, "${dateString(entry.date)} · ${entry.topic}\n${entry.question}") {
                            selectedReading = entry; screen = "saved"
                        }
                    }
                }
                "saved" -> selectedReading?.let { snapshot ->
                    val entry = history.find { it.id == snapshot.id } ?: snapshot
                    Heading(entry.title, dateString(entry.date) + " · " + entry.topic)
                    if (entry.question.isNotBlank()) SectionText("Вопрос", entry.question)
                    val savedCards = ReadingCodec.decode(entry.cards)
                    savedCards.forEach { card ->
                        CardPanel(card)
                        Text(TarotData.interpretation(card, entry.topic), modifier = Modifier.padding(bottom = 16.dp))
                    }
                    SectionText("Итог", TarotData.overview(savedCards))
                    var editedNotes by remember(entry.id) { mutableStateOf(entry.notes) }
                    OutlinedTextField(editedNotes, onValueChange = { editedNotes = it },
                        label = { Text("Заметки") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
                    Button(onClick = { vm.updateNotes(entry.id, editedNotes); screen = "journal" },
                        modifier = Modifier.fillMaxWidth()) { Text("Сохранить заметки") }
                    var confirm by remember { mutableStateOf(false) }
                    OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Удалить запись") }
                    if (confirm) AlertDialog(onDismissRequest = { confirm = false },
                        title = { Text("Удалить расклад?") }, text = { Text("Это действие нельзя отменить.") },
                        confirmButton = { TextButton(onClick = { vm.delete(entry.id); screen = "journal" }) { Text("Удалить") } },
                        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Отмена") } })
                }
                "learn" -> {
                    Heading("Учимся читать Таро", "Несколько простых шагов для знакомства с колодой.")
                    SectionText("1. Изучите колоду", "78 карт разделены на 22 Старших и 56 Младших Арканов. Старшие говорят о крупных темах, Младшие — о повседневности.")
                    SectionText("2. Сформулируйте вопрос", "Полезнее спрашивать «На что мне обратить внимание?», чем искать неизбежный прогноз.")
                    SectionText("3. Посмотрите на позиции", "У каждой позиции в раскладе своя роль. Сопоставляйте смысл карты с вопросом и местом.")
                    SectionText("4. Учитывайте контекст", "Перевёрнутая карта не обязательно означает что-то плохое. Она может описывать задержку или внутреннее переживание.")
                    SectionText("5. Запишите вывод", "Сохраните, какие ассоциации возникли и какое действие вы готовы выбрать.")
                    Button(onClick = { screen = "library" }) { Text("Перейти к картам") }
                }
                "settings" -> {
                    Heading("Настройки", "Приложение бесплатно, не показывает рекламу и работает без интернета.")
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Использовать перевёрнутые карты", modifier = Modifier.weight(1f))
                        Switch(checked = reversals, onCheckedChange = vm::setReversals)
                    }
                    SectionText("Приватность", "Расклады и заметки хранятся только в локальной базе. Приложение не запрашивает доступ к интернету. Автоматического резервного копирования нет.")
                    SectionText("Важно", "Таро используется для развлечения и личных размышлений. Оно не заменяет медицинские, финансовые и юридические консультации.")
                    SectionText("Версия", "1.0.0")
                }
            }
        }
    }
}
@Composable private fun Heading(title: String, subtitle: String) {
    Text(title, color = Gold, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Text(subtitle, color = Pale)
    Spacer(Modifier.height(22.dp))
}
@Composable private fun BigAction(title: String, subtitle: String, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
        shape = RoundedCornerShape(16.dp), color = Panel, border = BorderStroke(1.dp, Gold.copy(alpha = 0.22f))) {
        Column(Modifier.padding(17.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Pale, style = MaterialTheme.typography.bodySmall)
        }
    }
}
@Composable private fun SectionText(title: String, content: String) {
    Text(title, color = Gold, style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(7.dp))
    Text(content)
    Spacer(Modifier.height(22.dp))
}
@Composable private fun SymbolCard(title: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier.padding(bottom = 12.dp), color = Panel,
        shape = RoundedCornerShape(18.dp), border = BorderStroke(2.dp, Gold)) {
        Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Text("☾  ✦  ☼", color = Gold, style = MaterialTheme.typography.headlineLarge, textAlign = TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            Text(title, color = Gold, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            Text("✧  ✦  ✧", color = Pale, textAlign = TextAlign.Center)
        }
    }
}
@Composable private fun CardPanel(drawn: DrawnCard) {
    val card = TarotData.card(drawn.id)
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(drawn.position, color = Gold, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        SymbolCard(card.name, Modifier.width(180.dp).height(240.dp))
        Text(card.name + if (drawn.reversed) " · перевёрнутая" else " · прямая",
            fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
    }
}
private fun dateString(timestamp: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru")).format(Date(timestamp))
