package com.tainyarkanov.tarot

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Entity(tableName = "readings")
data class ReadingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long,
    val title: String,
    val topic: String,
    val question: String,
    val cards: String,
    val notes: String
)
@Dao
interface ReadingDao {
    @Query("SELECT * FROM readings ORDER BY date DESC, id DESC")
    fun observeAll(): Flow<List<ReadingEntity>>
    @Insert suspend fun insert(reading: ReadingEntity)
    @Query("DELETE FROM readings WHERE id = :id")
    suspend fun delete(id: Long)
    @Query("UPDATE readings SET notes = :notes WHERE id = :id")
    suspend fun updateNotes(id: Long, notes: String)
}
@Database(entities = [ReadingEntity::class], version = 1, exportSchema = false)
abstract class TarotDatabase : RoomDatabase() {
    abstract fun readings(): ReadingDao
    companion object {
        @Volatile private var INSTANCE: TarotDatabase? = null
        fun get(context: Context): TarotDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, TarotDatabase::class.java, "tarot_readings.db"
                ).build().also { INSTANCE = it }
            }
    }
}
private val Context.settingsStore by preferencesDataStore(name = "tarot_settings")
class UserSettings(private val context: Context) {
    private val reversalsKey = booleanPreferencesKey("reversals")
    val reversals: Flow<Boolean> = context.settingsStore.data.map { it[reversalsKey] ?: true }
    suspend fun setReversals(value: Boolean) {
        context.settingsStore.edit { it[reversalsKey] = value }
    }
}
object ReadingCodec {
    fun encode(cards: List<DrawnCard>): String =
        cards.joinToString(";") { "${it.id},${if (it.reversed) 1 else 0},${it.position.replace(",", " " ).replace(";", " ")}" }
    fun decode(raw: String): List<DrawnCard> = raw.split(";").mapNotNull { item ->
        val chunks = item.split(",", limit = 3)
        val id = chunks.getOrNull(0)?.toIntOrNull()
        if (id == null || id !in 0..77 || chunks.size != 3) null
        else DrawnCard(id, chunks[1] == "1", chunks[2])
    }
}
