package com.tainyarkanov.tarot

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class TarotViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = TarotDatabase.get(app).readings()
    private val settings = UserSettings(app)
    val history = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val reversals = settings.reversals.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    fun draw(spread: Spread): List<DrawnCard> = TarotData.draw(spread, reversals.value)
    fun daily(): List<DrawnCard> {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date())
        val seed = today.hashCode()
        return TarotData.draw(TarotData.spreads[0], false, Random(seed))
    }
    fun save(title: String, topic: String, question: String, cards: List<DrawnCard>, notes: String) {
        viewModelScope.launch {
            dao.insert(ReadingEntity(date = System.currentTimeMillis(), title = title, topic = topic,
                question = question, cards = ReadingCodec.encode(cards), notes = notes))
        }
    }
    fun delete(id: Long) { viewModelScope.launch { dao.delete(id) } }
    fun updateNotes(id: Long, notes: String) { viewModelScope.launch { dao.updateNotes(id, notes) } }
    fun setReversals(enabled: Boolean) { viewModelScope.launch { settings.setReversals(enabled) } }
}
