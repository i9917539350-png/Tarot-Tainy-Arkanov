package com.tainyarkanov.tarot

import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random

class TarotDataTest {
    @Test fun fullDeckHasUniqueIdsAndNames() {
        assertEquals(78, TarotData.cards.size)
        assertEquals(78, TarotData.cards.map { it.id }.toSet().size)
        assertEquals(78, TarotData.cards.map { it.name }.toSet().size)
        assertEquals((0..77).toList(), TarotData.cards.map { it.id })
    }
    @Test fun allSpreadsHaveNoRepeatedCards() {
        for (spread in TarotData.spreads) {
            val drawn = TarotData.draw(spread, true, Random(42))
            assertEquals(spread.positions.size, drawn.size)
            assertEquals(drawn.size, drawn.map { it.id }.toSet().size)
            assertEquals(spread.positions, drawn.map { it.position })
        }
    }
    @Test fun reversalsCanBeDisabled() {
        val drawn = TarotData.draw(TarotData.spreads[4], false, Random(42))
        assertTrue(drawn.none { it.reversed })
    }
    @Test fun cardTextsExist() {
        TarotData.cards.forEach {
            assertTrue(it.upright.length > 20)
            assertTrue(it.reversed.length > 20)
            assertTrue(it.symbol.isNotBlank())
        }
    }
    @Test fun serializationRoundTrip() {
        val original = TarotData.draw(TarotData.spreads[2], true, Random(55))
        assertEquals(original, ReadingCodec.decode(ReadingCodec.encode(original)))
    }
    @Test fun invalidSavedCardsAreIgnored() {
        assertTrue(ReadingCodec.decode("999,0,Title;invalid").isEmpty())
    }
    @Test fun interpretationDependsOnTopicAndOrientation() {
        val card = DrawnCard(0, false, "Совет")
        assertNotEquals(TarotData.interpretation(card, "Любовь"),
            TarotData.interpretation(card, "Работа"))
        assertNotEquals(TarotData.interpretation(card, "Любовь"),
            TarotData.interpretation(card.copy(reversed = true), "Любовь"))
    }
}
